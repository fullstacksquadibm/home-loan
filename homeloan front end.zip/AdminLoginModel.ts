export class AdminLoginModel{
    public username:String;
    public password:String;
}