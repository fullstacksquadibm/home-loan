export class Customer{
   public custId:number;
   public fullName :string;
   public email :string;
   public password :string;
   public cpassword :string;
   public mobile :string;  
   

}