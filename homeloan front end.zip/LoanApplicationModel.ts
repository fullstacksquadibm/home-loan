export class LoanApplicationModel{
   public loanId:number;
    public dateOfBirth:Date;
    public occupation:string;
    public income:number;
    public organisationName:string;
    public pan:string;
    public resiAddress:string;
    public propertyValue:string;
    public propertyConfig:string;
    public aadhar:string;
    public laonStatus:string;
    
}