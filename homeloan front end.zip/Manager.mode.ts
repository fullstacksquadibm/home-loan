export class Manager{
    public Username:string;
    public password:string;
}