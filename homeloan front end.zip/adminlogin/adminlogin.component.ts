import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminLoginModel } from '../AdminLoginModel';

import { AppService } from '../service/app.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  username:string="";
  password:string="";
  auth:AdminLoginModel;
  constructor(private router:Router,private service :AppService) { 
    this.auth=new AdminLoginModel();
  }
  // validate(){
  //   this.service.login(this.username,this.password).subscribe(data=>{
  //     if(data===null)
  //     alert('failed')
  //     else
  //     this.router.navigate(['/home']);
  //   });
  // }

  ngOnInit(): void {
  }

}
