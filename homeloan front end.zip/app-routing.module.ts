import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { LoanApplicationComponent } from './loan-application/loan-application.component';
import { ApprovedLoanComponent } from './approved-loan/approved-loan.component';
import { HomeComponent } from './home/home.component';
import { EmiComponent } from './emi/emi.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { LoaneditComponent } from './loanedit/loanedit.component';
import { CustomerloginComponent } from './customerlogin/customerlogin.component';
import { CustdashboardComponent } from './custdashboard/custdashboard.component';
import { Cust2Component } from './cust2/cust2.component';
import { La3Component } from './la3/la3.component';

const routes: Routes = [
  {path: 'home', redirectTo: '/home', pathMatch: 'full'},
  
  {path : 'login',component:LoginComponent},
  {path : 'register',component:RegisterComponent},
  {path : 'loan-application',component:LoanApplicationComponent},
  {path : 'approved-loan',component:ApprovedLoanComponent},
  {path : 'home',component:HomeComponent},
  {path:'emi',component:EmiComponent},
  {path:'admin',component:AdminloginComponent},
  {path:'loanedit',component:LoaneditComponent},
  {path:'custlogin',component:CustomerloginComponent},
  {path:'customerdash',component:CustdashboardComponent},
  {path:'cust2','component':Cust2Component},
  {path:'fileup',component:La3Component},
  {path: '**', redirectTo: '**', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
