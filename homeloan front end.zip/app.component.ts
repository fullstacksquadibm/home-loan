import { Component } from '@angular/core';
import { LoginModel } from './login.module';
import { UserService } from './services/user.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'home-loan';
  user : LoginModel;

  constructor(private service : UserService) {
    this.user = new LoginModel();
  }
  
  ngOnInit(): void {
    
  }

}
