import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { LoanApplicationComponent } from './loan-application/loan-application.component';
import { ApprovedLoanComponent } from './approved-loan/approved-loan.component';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';

import { EligibilitycalComponent } from './eligibilitycal/eligibilitycal.component';
import { EmiComponent } from './emi/emi.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { LoaneditComponent } from './loanedit/loanedit.component';
import { CustomerloginComponent } from './customerlogin/customerlogin.component';
import { CustdashboardComponent } from './custdashboard/custdashboard.component';
import { Cust2Component } from './cust2/cust2.component';
import { La3Component } from './la3/la3.component';
import { NgImageSliderModule } from 'ng-image-slider';




@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    LoanApplicationComponent,
    ApprovedLoanComponent,
    HomeComponent,
   
    EligibilitycalComponent,
    EmiComponent,
    AdminloginComponent,
    LoaneditComponent,
    CustomerloginComponent,
    CustdashboardComponent,
    Cust2Component,
    La3Component,
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgImageSliderModule
   
  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
