export class ApprovalModel{
    public userid:string;
    public approval_id:number;
    public loan_id:number;
    public start_date:number;
    public end_date:Date;
    public approval_amount:number;
    public interest_rate:number;
    public emi_amount:number;
    


}