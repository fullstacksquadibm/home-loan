import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { LoginModel } from '../login.module';
import { ApprovalService } from '../services/approval.service';
import { ApprovalModel } from '../approval.module';
import { LoanApplicationModel } from '../LoanApplicationModel';
import { LoanapplicationService } from '../services/loanapplication.service';
import { ApprovedLoanService } from '../services/approved-loan.service';
@Component({
  selector: 'app-approved-loan',
  templateUrl: './approved-loan.component.html',
  styleUrls: ['./approved-loan.component.css']
})
export class ApprovedLoanComponent implements OnInit {
 
  loanapplications:LoanApplicationModel[]=[];
  constructor( private service:ApprovedLoanService) {
   
   }

  ngOnInit(): void {
    this.service.listLoanApplications().then(data=>this.loanapplications=data);

  } 
  edit(index:number){
    // this.service.update(index);
    alert("Loan Approved successfully")
  }
  edit1(){
    alert("Loan Rejected..!")
  }


}
