import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust2',
  templateUrl: './cust2.component.html',
  styleUrls: ['./cust2.component.css']
})
export class Cust2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
