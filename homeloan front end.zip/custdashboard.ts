export class Custdashboard{
    public approvalid:number;
    public loanid:number;
    public startDate:string;
    public endDate:string;
    public approvedAmount:number;
    public intrestRate:number;
    public emiAmount:number;
    
}