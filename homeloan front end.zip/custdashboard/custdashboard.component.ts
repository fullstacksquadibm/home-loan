import { Component, OnInit } from '@angular/core';
import { Custdashboard } from '../custdashboard';
import { CustdashService } from '../services/custdash.service';

@Component({
  selector: 'app-custdashboard',
  templateUrl: './custdashboard.component.html',
  styleUrls: ['./custdashboard.component.css']
})
export class CustdashboardComponent implements OnInit {
 cust:Custdashboard[]=[];
  constructor(private service:CustdashService) { }

  ngOnInit(): void {
     this.cust=this.service.listLoandetails();
    

}
}
