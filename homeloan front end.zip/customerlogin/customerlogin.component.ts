import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { customerlogin } from '../customerloginmodel';
import { CustomerService } from '../services/customer.service';
import { CustomerserviceService } from '../services/customerservice.service';

@Component({
  selector: 'app-customerlogin',
  templateUrl: './customerlogin.component.html',
  styleUrls: ['./customerlogin.component.css']
})
export class CustomerloginComponent implements OnInit {
  customers:customerlogin;
  constructor(private service:CustomerserviceService,private router:Router) { 
    this.customers=new customerlogin();
  }

  ngOnInit(): void {
  }

  clogin()
  {
    console.log(localStorage.getItem("users"));
    let x = this.service.validate(this.customers);
    if(x!=null){
      
      localStorage.setItem("customers",JSON.stringify(x));
      this.router.navigate(["customerdash"]);
    }
    else
    this.router.navigate(["cust2"]);
  }

}
