export class customerlogin{
    public userid:string;
    public password:string;
}