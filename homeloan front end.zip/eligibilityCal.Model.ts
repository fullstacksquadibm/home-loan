export class CalculatorModel{
    age : number;
    tenure_yr : number;
    income_per_mth : number;
    roi : number;
    eligiblity : "??";
    calculatedMaxVal : 0.0;
}