import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eligibilitycal',
  templateUrl: './eligibilitycal.component.html',
  styleUrls: ['./eligibilitycal.component.css']
})
export class EligibilitycalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
