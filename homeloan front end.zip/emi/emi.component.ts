import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emi',
  templateUrl: './emi.component.html',
  styleUrls: ['./emi.component.css']
})
export class EmiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  
  principal:number=undefined;
  rate:number=undefined;
  time:number=undefined;
  si:number=undefined;
  amt:number=undefined;
  dem:number=undefined;

  simpleInterest(){
    this.si=(this.principal*this.rate*this.time)/(100*12);
     this.dem=this.si+this.principal;
     this.amt=this.dem/this.time;
     

   
  }

}
