import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

  imageObject: Array<object> = [
{
  image: 'assets/banner1.png',
    thumbImage: 'assets/thumb1.png',
    alt: 'Image alt'
},
{
  image: 'assets/banner2.png',
    thumbImage: 'assets/thumb2.png',
    alt: 'Image alt'
},


{
  image: 'assets/banner4.png',
    thumbImage: 'assets/thumb4.png',
    alt: 'Image alt'
},
{
  image: 'assets/banner3.png',
    thumbImage: 'assets/thumb3.png',
    alt: 'Image alt'
}


];
}

  


