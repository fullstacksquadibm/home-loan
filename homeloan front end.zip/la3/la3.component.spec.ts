import { ComponentFixture, TestBed } from '@angular/core/testing';

import { La3Component } from './la3.component';

describe('La3Component', () => {
  let component: La3Component;
  let fixture: ComponentFixture<La3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ La3Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(La3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
