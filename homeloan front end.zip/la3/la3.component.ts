import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-la3',
  templateUrl: './la3.component.html',
  styleUrls: ['./la3.component.css']
})
export class La3Component implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  demo(){
    alert("Loan Application Submitted Successfully");
    this.router.navigate(['home']);
  }

}
