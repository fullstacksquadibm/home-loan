import { Component, OnInit } from '@angular/core';
import { ApprovalService } from '../services/approval.service';
import { ApprovalModel } from '../approval.module';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { LoanApplicationModel } from '../LoanApplicationModel';
import { LoanapplicationService } from '../services/loanapplication.service';
@Component({
  selector: 'app-loan-application',
  templateUrl: './loan-application.component.html',
  styleUrls: ['./loan-application.component.css']
})
export class LoanApplicationComponent implements OnInit {


  la: LoanApplicationModel;

  employment: string[];

  static approval_id: number = 1001;
  static loan_id: number = 900080;
  EMI: number;
  salary: number;
  amount: number;
  approveUser: any;
  dateOfBirth: any;
  age: number;
  eage: number;
  approvalservice: any;
  constructor(private http: HttpClient, private router: Router, private laservice: LoanapplicationService) {
    this.la = new LoanApplicationModel();
    this.employment = ["Self-Employement", "Employement"];



  }

  ngOnInit(): void {
  }
  CalculateAge(): void {
    if (this.dateOfBirth) {
      const d = new Date(this.dateOfBirth);
      var timediff = Math.abs(Date.now() - d.getTime());
      this.age = Math.floor((timediff / (1000 * 3600 * 24)) / 365.25);

    }
  }

  CalculateLoanAmount(): any {
    if (this.age >= 60) {
      return 0;
    }
    else if ((this.age + 20) >= 0 && (this.age + 20) < 60) {
      this.eage = 20;
    }
    else {
      this.eage = 60 - this.age;
    }
    this.EMI = this.salary - (this.salary * (1 / 2.5));
    this.amount = this.EMI * 6 * this.eage;
    return this.amount;
  }

  validate() {
    this.CalculateAge();
    if (this.CalculateLoanAmount() == 0) {
      alert("Not ELigible for loan");
    }
    else {
      // localStorage.clear();
      // this.approveUser.amount=this.amount;
      // this.approveUser.approval_id=LoanApplicationComponent.approval_id;
      // LoanApplicationComponent.approval_id+=1;
      // this.approveUser.emi_amount=this.EMI;
      // this.approveUser.loan_id=LoanApplicationComponent.loan_id;
      // LoanApplicationComponent.loan_id+=1;
      // this.approveUser.start_date=Date.now();
      // this.approveUser.interest_rate=6;
      // let year=new Date;
      // year.setFullYear(year.getFullYear()+this.eage);
      // var CDate = new Date();
      // CDate.setDate(CDate.getDate());
      // var CMonth = new Date();
      // CMonth.setMonth(CMonth.getMonth() - 1);
      // this.approveUser.end_date=year;
      // console.log(this.approveUser);
      // this.approvalservice.addToApproval(this.approveUser);
      // localStorage.setItem("user",JSON.stringify(this.approveUser));

       this.laservice.saveLoanApplication(this.la);
      alert("Data submitted");
      this.router.navigate(['fileup']);


    }
  }
}
