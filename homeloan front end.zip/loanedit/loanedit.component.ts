import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loanedit',
  templateUrl: './loanedit.component.html',
  styleUrls: ['./loanedit.component.css']
})
export class LoaneditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
