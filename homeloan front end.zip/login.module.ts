export class LoginModel{
    public userid:string;
    public password:string;
}