import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginModel } from '../login.module';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user:LoginModel;
  constructor(private service:UserService, private router: Router) { 
    this.user = new LoginModel();
  }

  ngOnInit(): void {
  }
  LoggedIn(){
    console.log(localStorage.getItem("user"));
    let x = this.service.validate(this.user);
    if(x!=null){
      
      localStorage.setItem("user",JSON.stringify(x));
      this.router.navigate(["approved-loan"]);
    }
    else
    alert("User id or password doesn't match please try again!!!");
  }
  
}
