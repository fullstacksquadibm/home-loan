import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../CustomerModel';
import { LoginModel } from '../login.module';
import { CustomerService } from '../services/customer.service';
import { UserService } from '../services/user.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  
  cust:Customer;
  
  constructor(private router : Router,private service:CustomerService) {
 
    this.cust=new Customer();
   }

  ngOnInit(): void {}
  
  
  addCust(){
    this.service.saveCust(this.cust);
    this.router.navigate(['loan-application']);
    }

}
