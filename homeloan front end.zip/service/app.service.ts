import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Manager } from '../Manager.mode';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  private static baseurl:string="http://localhost:8880";
  manager:Manager[]=[];

  constructor(private http :HttpClient) { }

  // login(username:string,password:string){
  //   return this.http.get<Manager>(AppService.baseurl+"/login?username="+username+"&password="+password);

  // }

  
}
