import { Injectable } from '@angular/core';
import { ApprovalModel } from '../approval.module';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { LoginModel } from '../login.module';
@Injectable({
  providedIn: 'root'
})
export class ApprovalService {
approvedList:ApprovalModel[]=[];
  constructor(private router:Router, private http:HttpClient) {
    this.http.get<ApprovalModel[]>('../assets/approvedList.json').subscribe(data => this.approvedList = data);
    console.log(this.approvedList);
   }
   
   addToApproval(approved : ApprovalModel) {
      this.approvedList.push(approved);
      console.log(JSON.stringify(this.approvedList));
  }
  getApprovedList(){
    return this.approvedList;
  }
  searchByUserId(userid : string) {
    return this.approvedList.find(x => x.userid ==userid);
  }
  
}
