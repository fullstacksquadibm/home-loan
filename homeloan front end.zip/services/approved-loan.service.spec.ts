import { TestBed } from '@angular/core/testing';

import { ApprovedLoanService } from './approved-loan.service';

describe('ApprovedLoanService', () => {
  let service: ApprovedLoanService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ApprovedLoanService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
