import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { LoanApplicationModel } from '../LoanApplicationModel';
import { LoanapplicationService } from './loanapplication.service';

@Injectable({
  providedIn: 'root'
})
export class ApprovedLoanService {

  private static baseUrl="http://localhost:8880";
  la:LoanApplicationModel;

  constructor(private http:HttpClient,private router:Router) {

   }
   
  async listLoanApplications(){
    return this.http.get<LoanApplicationModel[]>(ApprovedLoanService.baseUrl+"/loanapplications").toPromise();
  }

  
  update(index : number) {
    this.router.navigate(['loanedit'], {queryParams: {index: index}});
  }
  
}
