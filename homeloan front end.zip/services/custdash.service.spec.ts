import { TestBed } from '@angular/core/testing';

import { CustdashService } from './custdash.service';

describe('CustdashService', () => {
  let service: CustdashService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustdashService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
