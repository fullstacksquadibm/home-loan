import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Custdashboard } from '../custdashboard';

@Injectable({
  providedIn: 'root'
})
export class CustdashService {
  custs:Custdashboard[]=[];
  

  constructor(private http:HttpClient) { 

    this.http.get<Custdashboard[]>('../assets/loandetails.json')
    .subscribe(data=>this.custs=data);
 
  }
  listLoandetails(){
    return this.custs;
  }


}
