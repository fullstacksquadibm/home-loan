import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Customer } from '../CustomerModel';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private static baseUrl:string="http://localhost:8880";
cust :Customer;

  constructor(private http:HttpClient) { }
 
  saveCust(c:Customer){
    this.http.post(CustomerService.baseUrl + "/customer",c)
    .subscribe(data => data = c);  
   }
}
