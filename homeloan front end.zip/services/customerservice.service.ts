import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { customerlogin } from '../customerloginmodel';

@Injectable({
  providedIn: 'root'
})
export class CustomerserviceService {
  customers:customerlogin[]=[];

  constructor(private router:Router,private http:HttpClient) {
    this.http.get<customerlogin[]>('../assets/users.json').subscribe(data => this.customers = data);
    console.log(this.customers);
   }
   validate(login : customerlogin) {
    return this.customers.find(x => x.userid == login.userid && x.password == login.password);
  }

   }

