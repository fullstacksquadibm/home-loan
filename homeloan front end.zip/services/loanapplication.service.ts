import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoanApplicationModel } from '../LoanApplicationModel';

@Injectable({
  providedIn: 'root'
})
export class LoanapplicationService {
  private static baseUrl:string="http://localhost:8880";

  constructor(private http:HttpClient) { }
  saveLoanApplication(la:LoanApplicationModel){
    this.http.post(LoanapplicationService.baseUrl+"/loanapplication",la)
    .subscribe(data => data = la);
  }
}
