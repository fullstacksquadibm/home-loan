import { Injectable } from '@angular/core';
import { LoginModel } from '../login.module';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class UserService {
users:LoginModel[]=[];

  constructor(private router:Router,private http:HttpClient) {
    this.http.get<LoginModel[]>('../assets/users.json').subscribe(data => this.users = data);
    console.log(this.users);
   }
   validate(login : LoginModel) {
    return this.users.find(x => x.userid == login.userid && x.password == login.password);
  }
  logout() {
    localStorage.removeItem("user");
    this.router.navigate(['login']);
  }
  addUser(user : LoginModel) {
    this.users.push(user);
    console.log(JSON.stringify(this.users));
  }
  getUsers(){
    return this.users;
  }

}
